﻿using System.Reflection;
using System.Runtime.InteropServices;

[assembly: Guid("bf002605-f599-4ddc-9ce8-fad707ef1a85")]
[assembly: ComVisible(false)]
[assembly: AssemblyTrademark("")]
[assembly: AssemblyCopyright("Copyright ©  2008")]
[assembly: AssemblyFileVersion("1.0.0.0")]
[assembly: AssemblyProduct("MHP2G Kor patch")]
[assembly: AssemblyCompany("한글날")]
[assembly: AssemblyConfiguration("")]
[assembly: AssemblyDescription("Monster Hunter 2G Kor Patch v1.1")]
[assembly: AssemblyTitle("Monster Hunter 2G Kor Patch")]
[assembly: AssemblyVersion("1.0.0.0")]
