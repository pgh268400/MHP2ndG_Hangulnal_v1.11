﻿// Decompiled with JetBrains decompiler
// Type: hpdPatchMHP2G.Properties.Resources
// Assembly: MonsterHunter2G KorPatch, Version=1.0.0.0, Culture=neutral, PublicKeyToken=null
// MVID: E2D0E602-1310-4EBF-B2D7-D651B15B3CDC
// Assembly location: E:\Game\PSP\MHP2ndG_Hangulnal_v1.11\MHP2G_Hangulnal.exe

using System.CodeDom.Compiler;
using System.ComponentModel;
using System.Diagnostics;
using System.Drawing;
using System.Globalization;
using System.Resources;
using System.Runtime.CompilerServices;

namespace hpdPatchMHP2G.Properties
{
  [GeneratedCode("System.Resources.Tools.StronglyTypedResourceBuilder", "2.0.0.0")]
  [DebuggerNonUserCode]
  [CompilerGenerated]
  internal class Resources
  {
    private static ResourceManager resourceMan;
    private static CultureInfo resourceCulture;

    internal Resources()
    {
    }

    [EditorBrowsable(EditorBrowsableState.Advanced)]
    internal static ResourceManager ResourceManager
    {
      get
      {
        if (object.ReferenceEquals((object) hpdPatchMHP2G.Properties.Resources.resourceMan, (object) null))
          hpdPatchMHP2G.Properties.Resources.resourceMan = new ResourceManager("hpdPatchMHP2G.Properties.Resources", typeof (hpdPatchMHP2G.Properties.Resources).Assembly);
        return hpdPatchMHP2G.Properties.Resources.resourceMan;
      }
    }

    [EditorBrowsable(EditorBrowsableState.Advanced)]
    internal static CultureInfo Culture
    {
      get
      {
        return hpdPatchMHP2G.Properties.Resources.resourceCulture;
      }
      set
      {
        hpdPatchMHP2G.Properties.Resources.resourceCulture = value;
      }
    }

    internal static Bitmap main1
    {
      get
      {
        return (Bitmap) hpdPatchMHP2G.Properties.Resources.ResourceManager.GetObject(nameof (main1), hpdPatchMHP2G.Properties.Resources.resourceCulture);
      }
    }

    internal static Bitmap main2
    {
      get
      {
        return (Bitmap) hpdPatchMHP2G.Properties.Resources.ResourceManager.GetObject(nameof (main2), hpdPatchMHP2G.Properties.Resources.resourceCulture);
      }
    }

    internal static Bitmap main3
    {
      get
      {
        return (Bitmap) hpdPatchMHP2G.Properties.Resources.ResourceManager.GetObject(nameof (main3), hpdPatchMHP2G.Properties.Resources.resourceCulture);
      }
    }

    internal static Bitmap main4
    {
      get
      {
        return (Bitmap) hpdPatchMHP2G.Properties.Resources.ResourceManager.GetObject(nameof (main4), hpdPatchMHP2G.Properties.Resources.resourceCulture);
      }
    }

    internal static Bitmap main5
    {
      get
      {
        return (Bitmap) hpdPatchMHP2G.Properties.Resources.ResourceManager.GetObject(nameof (main5), hpdPatchMHP2G.Properties.Resources.resourceCulture);
      }
    }

    internal static Bitmap main6
    {
      get
      {
        return (Bitmap) hpdPatchMHP2G.Properties.Resources.ResourceManager.GetObject(nameof (main6), hpdPatchMHP2G.Properties.Resources.resourceCulture);
      }
    }

    internal static Bitmap main7
    {
      get
      {
        return (Bitmap) hpdPatchMHP2G.Properties.Resources.ResourceManager.GetObject(nameof (main7), hpdPatchMHP2G.Properties.Resources.resourceCulture);
      }
    }

    internal static Bitmap main8
    {
      get
      {
        return (Bitmap) hpdPatchMHP2G.Properties.Resources.ResourceManager.GetObject(nameof (main8), hpdPatchMHP2G.Properties.Resources.resourceCulture);
      }
    }

    internal static Bitmap main9
    {
      get
      {
        return (Bitmap) hpdPatchMHP2G.Properties.Resources.ResourceManager.GetObject(nameof (main9), hpdPatchMHP2G.Properties.Resources.resourceCulture);
      }
    }

    internal static Bitmap warn
    {
      get
      {
        return (Bitmap) hpdPatchMHP2G.Properties.Resources.ResourceManager.GetObject(nameof (warn), hpdPatchMHP2G.Properties.Resources.resourceCulture);
      }
    }
  }
}
