﻿// Decompiled with JetBrains decompiler
// Type: hpdPatchMHP2G.Properties.Settings
// Assembly: MonsterHunter2G KorPatch, Version=1.0.0.0, Culture=neutral, PublicKeyToken=null
// MVID: E2D0E602-1310-4EBF-B2D7-D651B15B3CDC
// Assembly location: E:\Game\PSP\MHP2ndG_Hangulnal_v1.11\MHP2G_Hangulnal.exe

using System.CodeDom.Compiler;
using System.Configuration;
using System.Runtime.CompilerServices;

namespace hpdPatchMHP2G.Properties
{
  [GeneratedCode("Microsoft.VisualStudio.Editors.SettingsDesigner.SettingsSingleFileGenerator", "8.0.0.0")]
  [CompilerGenerated]
  internal sealed class Settings : ApplicationSettingsBase
  {
    private static Settings defaultInstance = (Settings) SettingsBase.Synchronized((SettingsBase) new Settings());

    public static Settings Default
    {
      get
      {
        return Settings.defaultInstance;
      }
    }
  }
}
